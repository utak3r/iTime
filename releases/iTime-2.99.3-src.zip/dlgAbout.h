#ifndef DLGABOUT_H
#define DLGABOUT_H

BOOL CALLBACK dlgAboutProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

#endif // DLGABOUT_H

