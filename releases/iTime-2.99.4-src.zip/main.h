#ifndef MAIN_H
#define MAIN_H

#include <windows.h>
#include "resource.h"

extern HWND hwnd;
extern HINSTANCE hAppInstance;

extern char *pszdlgMainNapis;


#endif // MAIN_H

