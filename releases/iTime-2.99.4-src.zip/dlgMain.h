#ifndef DLGMAIN_H
#define DLGMAIN_H

#include <windows.h>
#include "main.h"

BOOL CALLBACK dlgMainProc (HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);
void dlgMainCreate();

#endif // DLGMAIN_H

